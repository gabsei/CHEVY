let yesButton = document.getElementById('yesBtn');
let noButton = document.getElementById('noBtn');
let question1Div = document.getElementById('question1');
let finalMessageDiv = document.getElementById('final-message');
let clickCount = 0;

// Move the button on "Yes" click
yesButton.addEventListener('click', function() {
    clickCount++;

    // Move the button to a random position
    yesButton.style.position = 'absolute';
    yesButton.style.top = Math.random() * (window.innerHeight - 50) + 'px';
    yesButton.style.left = Math.random() * (window.innerWidth - 100) + 'px';

    // Change the button text after specific clicks
    if (clickCount === 3) {
        yesButton.textContent = "PINDUTIN MO NA >:(";
    } else if (clickCount === 4) {
        yesButton.textContent = "YAY LOV U";
        question1Div.style.display = 'none'; // Hide first question
        finalMessageDiv.style.display = 'block'; // Show final message
    }
});

// Handle "No" button click
noButton.addEventListener('click', function() {
    noButton.textContent = "YES DAPAT <3";
});

// Redirect to custom link on final button click
document.getElementById('finalBtn').addEventListener('click', function() {
    window.location.href = "https://app.sane.fyi/gabiii/a058bfb8-6970-11ef-ba3e-2f025f7e3fb4"; // Replace with your actual link
});
